from scrapy import cmdline

cmdline.execute("scrapy runspider sickList.py".split())
