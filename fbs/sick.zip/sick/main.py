from scrapy.cmdline import execute

execute("scrapy crawl sickList".split())
