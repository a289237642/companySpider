create view v_gaoxueya as
  select `q`.`id`             AS `id`,
         `q`.`question_title` AS `question_title`,
         `q`.`question_time`  AS `question_time`,
         `q`.`disease`        AS `disease`,
         `q`.`question`       AS `question`,
         `q`.`question_url`   AS `question_url`,
         `d`.`doctor`         AS `doctor`,
         `d`.`level`          AS `level`,
         `d`.`good_num`       AS `good_num`,
         `d`.`bad_num`        AS `bad_num`,
         `d`.`answers`        AS `answers`,
         `d`.`answers_time`   AS `answers_time`,
         `d`.`wt_url`         AS `wt_url`
  from (`ai_gaoxueya`.`z_gaoxueya_answers` `q` join `ai_gaoxueya`.`z_gaoxueya_doctor` `d` on ((`q`.`question_url` =
                                                                                               `d`.`wt_url`)))
  order by field(`d`.`level`, '主治医师', '住院医师', '医师', NULL), `d`.`good_num` desc, length(`d`.`answers`) desc,
           `d`.`answers_time` desc;

